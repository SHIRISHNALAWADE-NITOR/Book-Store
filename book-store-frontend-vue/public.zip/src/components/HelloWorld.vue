<template>
  <div class="hello">
    Welcome
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  props: {
    
  }
}
</script>


<style scoped>

</style>
