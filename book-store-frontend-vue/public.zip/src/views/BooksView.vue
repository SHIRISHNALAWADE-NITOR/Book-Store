 <template>
  <div class="product-list-container">
    <div class="product-card" v-for="book in paginatedBooks" :key="book.bookId" @click="goToDetail(book.bookId)">
      <img :src="book.imageUrl" alt="Product Image" class="product-image" />
      <p class="product-name">{{ book.title }}</p>
      <p class="product-price">{{ (book.price).toFixed(2) }} ₹</p>
    </div>
    <div class="pagination-controls">
      <button @click="previousPage" :disabled="currentPage === 1">Previous</button>
      <span>Page {{ currentPage }} of {{ totalPages }}</span>
      <button @click="nextPage" :disabled="currentPage === totalPages">Next</button>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  name: 'BooksView',
  data() {
    return {
      books: [],
      currentPage: 1,
      booksPerPage: 12,
      totalPages: 1
    };
  },
  computed: {
    paginatedBooks() {
      const start = (this.currentPage - 1) * this.booksPerPage;
      const end = start + this.booksPerPage;
      return this.books.slice(start, end);
    }
  },
  methods: {
    
    async fetchBooks() {
      try {
        const response = await axios.get('https://localhost:7044/api/Book');
        this.books = response.data;
        this.totalPages = Math.ceil(this.books.length / this.booksPerPage);
      } catch (error) {
        console.error('Error fetching books:', error);
      }
    },
    goToDetail(bookId) {
      this.$router.push({ name: 'ProductDetail', params: { id: bookId } });
    },
    previousPage() {
      if (this.currentPage > 1) {
        this.currentPage--;
      }
    },
    nextPage() {
      if (this.currentPage < this.totalPages) {
        this.currentPage++;
      }
    },
    setPage(page) {
      this.currentPage = page;
    }
  },
  created() {
    this.fetchBooks();
  }
};
</script>




<style scoped>
.product-list-container {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-around;
  padding: 20px;
}

.product-card {
  width: 22%; /* Adjusted width to fit more cards */
  background: #f9f9f9;
  margin-bottom: 15px; /* Reduced bottom margin */
  padding: 10px; /* Reduced padding */
  text-align: center;
  border: 1px solid #ddd;
  border-radius: 5px;
  cursor: pointer;
  transform: scale(0.9); /* Scale down by 10% */
  transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out; /* Smooth transition effect for transform and shadow */
}

.product-card:hover {
  transform: scale(1); /* Restore to original size on hover */
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Add shadow effect on hover */
}

.product-image {
  width: 100%;
  height: auto;
  margin-bottom: 10px;
}

.product-name,
.product-price {
  margin: 5px 0;
}

.pagination-controls {
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 20px 0; /* Margin top for spacing */
}

.pagination-controls button {
  margin: 0 0.5rem; /* Adjusted margin */
  padding: 0.5rem 1rem; /* Adjusted padding */
  font-size: 1rem; /* Font size for readability */
  border: 1px solid #ddd; /* Border for visibility */
  border-radius: 5px; /* Rounded corners */
  background-color: #fff; /* Background color */
  cursor: pointer; /* Pointer cursor */
  transition: background-color 0.2s, color 0.2s; /* Transition for hover effects */
}

.pagination-controls button:hover {
  background-color: #007bff; /* Hover background color */
  color: #fff; /* Hover text color */
}

.pagination-controls button:disabled {
  cursor: not-allowed; /* Disabled cursor */
  opacity: 0.5; /* Disabled opacity */
}

.pagination-controls span {
  margin: 0 1rem; /* Margin around the page number display */
  font-size: 1rem; /* Font size for readability */
}
</style>
