<template>
    <div class="terms-of-service">
        <h1>Terms of Service</h1>
        <p>Welcome to Pustak Paradise! By accessing and using our website, you agree to comply with and be bound by the following terms and conditions. Please review them carefully.</p>

        <h2>1. Acceptance of Terms</h2>
        <p>By using our website and purchasing products from us, you agree to these Terms of Service. If you do not agree with any part of these terms, please do not use our website.</p>

        <h2>2. Changes to Terms</h2>
        <p>We reserve the right to modify these terms at any time. Any changes will be posted on this page, and your continued use of the website after such changes constitutes your acceptance of the new terms.</p>

        <h2>3. Products and Services</h2>
        <p>We offer a wide range of books and related products. While we strive to provide accurate descriptions, we do not guarantee that the content on our website is accurate, complete, or current. We reserve the right to correct any errors and change or discontinue any products without prior notice.</p>

        <h2>4. Ordering and Payment</h2>
        <p>All orders placed through our website are subject to our acceptance. We may refuse or cancel any order at our discretion. Payment for products must be made at the time of purchase. We accept various payment methods, which will be specified on the checkout page.</p>

        <h2>5. Shipping and Delivery</h2>
        <p>We strive to process and ship orders promptly. Delivery times may vary based on your location and other factors. We are not responsible for delays caused by third-party carriers or other issues beyond our control.</p>

        <h2>6. Returns and Refunds</h2>
        <p>If you are not satisfied with your purchase, please contact our customer service team to discuss return and refund options. Returns are subject to our return policy, which can be found on our website.</p>

        <h2>7. Intellectual Property</h2>
        <p>All content on our website, including text, images, and logos, is the property of Pustak Paradise or its licensors and is protected by intellectual property laws. You may not use any content from our website without our express written permission.</p>

        <h2>8. User Conduct</h2>
        <p>You agree to use our website only for lawful purposes and in a manner that does not infringe on the rights of others or restrict their use and enjoyment of the website. Prohibited activities include, but are not limited to, hacking, spamming, and uploading harmful content.</p>

        <h2>9. Limitation of Liability</h2>
        <p>To the fullest extent permitted by law, Pustak Paradise shall not be liable for any indirect, incidental, consequential, or punitive damages arising from your use of the website or the purchase of products.</p>

        <h2>10. Governing Law</h2>
        <p>These terms shall be governed by and construed in accordance with the laws of [Your Jurisdiction]. Any disputes arising from these terms or your use of the website shall be resolved in the courts located in [Your Jurisdiction].</p>

        <h2>11. Contact Us</h2>
        <p>If you have any questions or concerns about these Terms of Service, please contact us at:</p>
        <p>Email: support@pustakparadise.com<br>
        Address: [Your Address Here]</p>

        <p>Thank you for choosing Pustak Paradise. We hope you enjoy your shopping experience!</p>
    </div>
</template>

<script>
export default {
    name: 'TermsOfServiceView',
    components: {}
}
</script>

<style scoped>
.terms-of-service {
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
    font-family: Arial, sans-serif;
}

h1 {
    font-size: 2em;
    margin-bottom: 20px;
}

h2 {
    font-size: 1.5em;
    margin-top: 20px;
}

p {
    line-height: 1.6;
    margin-bottom: 10px;
}
</style>
