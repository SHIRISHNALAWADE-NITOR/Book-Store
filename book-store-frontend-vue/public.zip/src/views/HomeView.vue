<template>
  <div>
    <CarouselComponent/>
    <h1>Categories</h1>
    
    <SlidingCards/>
    <h1>Bestseller</h1>

  </div>
</template>

<script>
import CarouselComponent from '@/components/CarouselComponent.vue';
import SlidingCards from '@/components/SlidingCards.vue';

export default {
  name: 'HomeView',
  components: {
    CarouselComponent,
    SlidingCards
  }
};
</script>

<style scoped>
/* Scoped styles for HomeView component */
</style>
