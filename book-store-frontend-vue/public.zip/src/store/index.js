// import { createStore } from 'vuex';

// const store = createStore({
//   state: {
//     user: null, // Default state for user
//   },
//   mutations: {
//     setUser(state, user) {
//       state.user = user;
//     },
//     logout(state) {
//       state.user = null;
//     }
//   },
//   actions: {
//     login({ commit }, user) {
//       // Simulate login process and set user data
//       commit('setUser', user);
//       // Optionally store in localStorage/sessionStorage
//       localStorage.setItem('user', JSON.stringify(user));
//     },
//     logout({ commit }) {
//       commit('logout');
//       localStorage.removeItem('user');
//     },
//     initialize({ commit }) {
//       const user = JSON.parse(localStorage.getItem('user'));
//       if (user) {
//         commit('setUser', user);
//       }
//     }
//   },
//   getters: {
//     isAuthenticated(state) {
//       return !!state.user;
//     },
//     currentUser(state) {
//       return state.user;
//     }
//   }
// });

// export default store;

import { createStore } from 'vuex';
import createPersistedState from 'vuex-persistedstate';
import { showToast } from '@/utils/toastify'; // Adjust the path according to your project structure

const store = createStore({
  state: {
    user: null, // Default state for user
    cart: []    // State for cart items
  },
  mutations: {
    setUser(state, user) {
      state.user = user;
    },
    logout(state) {
      state.user = null;
    },
    ADD_TO_CART(state, book) {
      // Add a book to the cart
      const existingItem = state.cart.find(item => item.bookId === book.bookId);
      if (!existingItem) {
        state.cart.push(book);
        showToast('Book added to cart!');
      }
    },
    REMOVE_FROM_CART(state, bookId) {
      // Remove a book from the cart by its ID
      state.cart = state.cart.filter(item => item.bookId !== bookId);
      showToast('Book removed from cart!');
    },
    CLEAR_CART(state) {
      // Clear all items from the cart
      state.cart = [];
      showToast('Cart cleared!');
    }
  },
  actions: {
    login({ commit }, user) {
      // Simulate login process and set user data
      commit('setUser', user);
      // Optionally store in localStorage/sessionStorage
      localStorage.setItem('user', JSON.stringify(user));
    },
    logout({ commit }) {
      commit('logout');
      localStorage.removeItem('user');
    },
    initialize({ commit }) {
      const user = JSON.parse(localStorage.getItem('user'));
      if (user) {
        commit('setUser', user);
      }
    },
    addToCart({ commit }, book) {
      commit('ADD_TO_CART', book);
    },
    removeFromCart({ commit }, bookId) {
      commit('REMOVE_FROM_CART', bookId);
    },
    clearCart({ commit }) {
      commit('CLEAR_CART');
    }
  },
  getters: {
    isAuthenticated(state) {
      return !!state.user;
    },
    currentUser(state) {
      return state.user;
    },
    cart(state) {
      return state.cart;
    },
    cartItemCount(state) {
      return state.cart.length;
    },
    cartTotal(state) {
      return state.cart.reduce((total, item) => total + item.price, 0);
    }
  },
  plugins: [createPersistedState()]
});

export default store;
